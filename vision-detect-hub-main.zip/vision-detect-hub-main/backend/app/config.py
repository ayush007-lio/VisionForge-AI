import os
from dotenv import load_dotenv

load_dotenv()

MODEL_PATH = os.getenv("MODEL_PATH", "models/best.pt")
CONF_THRESHOLD = float(os.getenv("CONF_THRESHOLD", "0.25"))
IMG_SIZE = int(os.getenv("IMG_SIZE", "640"))
MAX_UPLOAD_MB = 10
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp", "image/bmp"}
CLASS_NAMES = {
    0: "Crack",
    1: "Surface Porosity",
    2: "Corrosion / Oxidation",
    3: "Scratch",
    4: "Deformation / Structural",
}
