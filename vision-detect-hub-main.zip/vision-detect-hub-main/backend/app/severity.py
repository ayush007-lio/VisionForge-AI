"""Severity engine + PASS/FAIL verdict. Mirrors src/lib/severity.ts in the web app."""
SEVERITIES = ["Low", "Medium", "High", "Critical"]
TYPE_WEIGHT = {"Crack": 3, "Deformation / Structural": 2.5, "Surface Porosity": 1.5,
               "Corrosion / Oxidation": 1.5, "Scratch": 1}


def severity(defect_type: str, area_frac: float, conf: float) -> str:
    s = TYPE_WEIGHT.get(defect_type, 1) * (0.6 + conf) * (1 + min(area_frac, 0.3) * 8)
    return "Critical" if s >= 6 else "High" if s >= 3.8 else "Medium" if s >= 2.2 else "Low"


def verdict(defects, min_conf=0.5, fail_severity="Medium", max_defects=0):
    kept = [d for d in defects if d["confidence"] >= min_conf]
    rank = SEVERITIES.index
    reasons = []
    if any(rank(d["severity"]) >= rank(fail_severity) for d in kept):
        reasons.append(f"Defect severity >= {fail_severity}")
    if len(kept) > max_defects:
        reasons.append(f"{len(kept)} defects exceed limit {max_defects}")
    if any(d["defect_type"] == "Crack" for d in kept):
        reasons.append("Crack detected")
    return ("FAIL" if reasons else "PASS"), kept, reasons
