"""FastAPI server for the AI-Based Industrial Defect Detection System (academic demo)."""
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .config import ALLOWED_TYPES, MAX_UPLOAD_MB
from .inference import predict, load_model
from .preprocessing import decode_image, validate
from .severity import verdict

app = FastAPI(title="AI Industrial Defect Detection API",
              description="Academic / demonstration system. Not connected to any production line.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": load_model() is not None}


@app.post("/api/inspect")
async def inspect(file: UploadFile = File(...), min_confidence: float = Form(0.5),
                  fail_severity: str = Form("Medium"), max_defects: int = Form(0)):
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, "Unsupported image format")
    data = await file.read()
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, "File too large")
    try:
        img = decode_image(data)
        validate(img)
    except ValueError as e:
        raise HTTPException(422, str(e))
    result = predict(img)
    v, kept, reasons = verdict(result["defects"], min_confidence, fail_severity, max_defects)
    return {**result, "verdict": v, "defects": kept, "reasons": reasons}
