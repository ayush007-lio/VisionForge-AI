"""OpenCV preprocessing pipeline for industrial surface images."""
import cv2
import numpy as np


def decode_image(data: bytes) -> np.ndarray:
    arr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image")
    return img


def validate(img: np.ndarray, min_side: int = 128) -> None:
    h, w = img.shape[:2]
    if min(h, w) < min_side:
        raise ValueError(f"Resolution too low ({w}x{h}); minimum {min_side}px")


def preprocess(img: np.ndarray, size: int = 640) -> np.ndarray:
    """Denoise -> CLAHE contrast equalisation on L channel -> letterbox resize."""
    den = cv2.fastNlMeansDenoisingColored(img, None, 5, 5, 7, 21)
    lab = cv2.cvtColor(den, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(l)
    eq = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
    return letterbox(eq, size)


def letterbox(img: np.ndarray, size: int) -> np.ndarray:
    h, w = img.shape[:2]
    s = size / max(h, w)
    resized = cv2.resize(img, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    canvas = np.full((size, size, 3), 114, np.uint8)
    canvas[: resized.shape[0], : resized.shape[1]] = resized
    return canvas


def classical_anomaly_map(img: np.ndarray) -> np.ndarray:
    """Fallback: Sobel gradient + local darkness anomaly map (0..1). Mirrors the web demo mode."""
    gray = cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (5, 5), 0).astype(np.float32)
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1)
    mag = cv2.magnitude(gx, gy)
    dark = np.clip(gray.mean() - gray, 0, None)
    score = (mag - mag.mean()) / (mag.std() + 1e-6) + 0.8 * (dark - dark.mean()) / (dark.std() + 1e-6)
    return cv2.normalize(score, None, 0, 1, cv2.NORM_MINMAX)


def classical_boxes(img: np.ndarray, thresh: float = 0.7):
    amap = classical_anomaly_map(img)
    mask = (amap > thresh).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask)
    h, w = img.shape[:2]
    boxes = []
    for i in range(1, n):
        x, y, bw, bh, area = stats[i]
        if area < 0.0005 * w * h:
            continue
        boxes.append({"x": x / w, "y": y / h, "w": bw / w, "h": bh / h, "area": int(area)})
    return boxes
