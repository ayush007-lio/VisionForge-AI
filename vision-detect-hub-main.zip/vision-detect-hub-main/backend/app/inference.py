"""YOLOv8 inference wrapper with an explicit, labelled classical-CV fallback."""
from pathlib import Path
import time
import numpy as np

from .config import MODEL_PATH, CONF_THRESHOLD, IMG_SIZE, CLASS_NAMES
from .preprocessing import preprocess, classical_boxes
from .severity import severity

_model = None


def load_model():
    global _model
    if _model is None and Path(MODEL_PATH).exists():
        from ultralytics import YOLO
        _model = YOLO(MODEL_PATH)
    return _model


def predict(img: np.ndarray) -> dict:
    t0 = time.time()
    model = load_model()
    h, w = img.shape[:2]
    defects = []
    if model is not None:
        pre = preprocess(img, IMG_SIZE)
        scale = IMG_SIZE / max(h, w)
        res = model.predict(pre, conf=CONF_THRESHOLD, imgsz=IMG_SIZE, verbose=False)[0]
        for box, cls, conf in zip(res.boxes.xyxy.cpu().numpy(), res.boxes.cls.cpu().numpy(), res.boxes.conf.cpu().numpy()):
            x1, y1, x2, y2 = box / scale
            name = CLASS_NAMES.get(int(cls), "Unknown")
            b = {"x": x1 / w, "y": y1 / h, "w": (x2 - x1) / w, "h": (y2 - y1) / h}
            defects.append({"defect_type": name, "confidence": round(float(conf), 3),
                            "severity": severity(name, b["w"] * b["h"], float(conf)), **b,
                            "explanation": f"YOLOv8 detection of class '{name}'."})
        mode, model_name = "model", f"YOLOv8 ({MODEL_PATH})"
    else:
        # DEMO FALLBACK: no trained weights found. Classical CV only — clearly labelled.
        for b in classical_boxes(img):
            aspect = max(b["w"] * w, b["h"] * h) / max(1, min(b["w"] * w, b["h"] * h))
            name = "Scratch" if aspect > 3 else "Surface Porosity"
            conf = 0.5
            defects.append({"defect_type": name, "confidence": conf,
                            "severity": severity(name, b["w"] * b["h"], conf),
                            "x": b["x"], "y": b["y"], "w": b["w"], "h": b["h"],
                            "explanation": "Classical CV anomaly region (fallback, not a trained model)."})
        mode, model_name = "demo", "DEMO FALLBACK: classical CV"
    return {"defects": defects, "mode": mode, "model_name": model_name,
            "processing_ms": int((time.time() - t0) * 1000), "width": w, "height": h}
