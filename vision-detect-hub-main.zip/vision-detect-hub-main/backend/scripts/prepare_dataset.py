"""Split a folder of images + YOLO labels into train/val/test (70/20/10)."""
import argparse, random, shutil
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--src", required=True, help="folder with images/ and labels/")
p.add_argument("--dst", default="datasets/defects")
a = p.parse_args()

imgs = sorted(Path(a.src, "images").glob("*.*"))
random.seed(42); random.shuffle(imgs)
n = len(imgs)
splits = {"train": imgs[: int(.7 * n)], "val": imgs[int(.7 * n): int(.9 * n)], "test": imgs[int(.9 * n):]}
for s, files in splits.items():
    for f in files:
        shutil.copy(f, Path(a.dst, "images", s, f.name))
        lbl = Path(a.src, "labels", f.stem + ".txt")
        if lbl.exists():
            shutil.copy(lbl, Path(a.dst, "labels", s, lbl.name))
    print(s, len(files))
