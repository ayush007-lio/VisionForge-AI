"""Train a YOLOv8 defect detector.  python scripts/train.py --epochs 100 --model yolov8s.pt"""
import argparse
from ultralytics import YOLO

p = argparse.ArgumentParser()
p.add_argument("--data", default="datasets/defects/data.yaml")
p.add_argument("--model", default="yolov8n.pt")
p.add_argument("--epochs", type=int, default=100)
p.add_argument("--imgsz", type=int, default=640)
p.add_argument("--batch", type=int, default=16)
a = p.parse_args()

model = YOLO(a.model)  # transfer learning from COCO-pretrained weights
model.train(data=a.data, epochs=a.epochs, imgsz=a.imgsz, batch=a.batch,
            hsv_h=0.015, hsv_s=0.5, hsv_v=0.4, fliplr=0.5, flipud=0.5, degrees=10, mosaic=1.0,
            patience=25, project="runs", name="defects")
print("Copy runs/defects/weights/best.pt to models/best.pt to serve it.")
