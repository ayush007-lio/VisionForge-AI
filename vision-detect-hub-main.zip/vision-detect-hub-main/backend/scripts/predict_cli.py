"""Run inference on a single image from the command line and draw boxes."""
import sys, json, cv2
sys.path.insert(0, ".")
from app.inference import predict

img = cv2.imread(sys.argv[1])
r = predict(img)
h, w = img.shape[:2]
for d in r["defects"]:
    x, y = int(d["x"] * w), int(d["y"] * h)
    cv2.rectangle(img, (x, y), (x + int(d["w"] * w), y + int(d["h"] * h)), (0, 0, 255), 2)
    cv2.putText(img, f'{d["defect_type"]} {d["confidence"]:.2f}', (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, .5, (0, 0, 255), 1)
cv2.imwrite("prediction.jpg", img)
print(json.dumps(r, indent=2))
