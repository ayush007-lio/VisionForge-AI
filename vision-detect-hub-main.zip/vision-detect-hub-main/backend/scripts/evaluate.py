"""Evaluate a trained model: mAP50, mAP50-95, precision, recall, per-class metrics, confusion matrix."""
import argparse, json
from ultralytics import YOLO

p = argparse.ArgumentParser()
p.add_argument("--weights", default="models/best.pt")
p.add_argument("--data", default="datasets/defects/data.yaml")
p.add_argument("--split", default="test")
a = p.parse_args()

m = YOLO(a.weights).val(data=a.data, split=a.split, plots=True)
report = {
    "mAP50": float(m.box.map50), "mAP50_95": float(m.box.map),
    "precision": float(m.box.mp), "recall": float(m.box.mr),
    "per_class_mAP50_95": {m.names[i]: float(v) for i, v in enumerate(m.box.maps)},
}
print(json.dumps(report, indent=2))
json.dump(report, open("evaluation_report.json", "w"), indent=2)
