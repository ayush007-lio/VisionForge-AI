# Companion Backend — AI Industrial Defect Detection (academic demo)

Standalone Python service for local demonstration of a self-trained detector.
**Academic/demonstration system — not connected to any real production line.**

## Setup
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000   # http://localhost:8000/docs
```
Without `models/best.pt` the API runs in a clearly labelled **DEMO FALLBACK** (classical OpenCV).

## Pipeline
1. `preprocessing.py` — decode, validate, denoise, CLAHE, letterbox (OpenCV)
2. `inference.py` — YOLOv8 inference → boxes, classes, confidences
3. `severity.py` — severity engine + PASS/FAIL verdict (same rules as the web app)

## Train / evaluate
```bash
python scripts/prepare_dataset.py --src /path/to/NEU-DET-yolo
python scripts/train.py --model yolov8s.pt --epochs 100
cp runs/defects/weights/best.pt models/best.pt
python scripts/evaluate.py --split test        # mAP, precision, recall, confusion matrix
python scripts/predict_cli.py sample.jpg
```

## Dataset layout
```
datasets/defects/
  data.yaml
  images/{train,val,test}/
  labels/{train,val,test}/   # YOLO txt: class cx cy w h (normalized)
```
Classes: crack, porosity, corrosion, scratch, deformation. Public sources: NEU-DET, MVTec AD, GC10-DET, KolektorSDD.
