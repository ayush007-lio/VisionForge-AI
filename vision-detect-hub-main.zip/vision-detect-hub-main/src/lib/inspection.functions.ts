import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { computeSeverity, computeVerdict, DEFECT_TYPES, SEVERITIES, type Defect, type Profile } from "./severity";

const MODEL = "google/gemini-3-flash-preview";

const defectSchema = z.object({
  defect_type: z.string().max(60),
  confidence: z.number().min(0).max(1),
  severity: z.enum(SEVERITIES),
  x: z.number().min(0).max(1),
  y: z.number().min(0).max(1),
  w: z.number().min(0).max(1),
  h: z.number().min(0).max(1),
  explanation: z.string().max(600),
});

const inputSchema = z.object({
  imageBase64: z.string().min(100).max(12_000_000),
  fileName: z.string().max(200),
  width: z.number().int().min(64).max(20000),
  height: z.number().int().min(64).max(20000),
  profileId: z.string().uuid().nullable(),
  mode: z.enum(["ai", "demo"]),
  demoDefects: z.array(defectSchema).max(20).optional(),
});

async function aiInspect(base64: string, profile: Profile | null) {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("AI model is not configured");
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            "You are an industrial visual-inspection vision model. Detect only real, visible surface defects. " +
            `Allowed classes: ${DEFECT_TYPES.join(", ")}. For each defect return a tight bounding box as box_2d [ymin, xmin, ymax, xmax] normalized 0-1000, ` +
            "a calibrated confidence 0-1, and a concise engineering explanation (morphology, likely cause). Do not invent defects; normal machining marks, holes by design, reflections and textures are NOT defects. " +
            "Also report no_defect_confidence: your confidence (0-1) that the part is free of defects if none found.",
        },
        {
          role: "user",
          content: [
            { type: "text", text: `Component profile: ${profile?.name ?? "Generic"} (${profile?.material ?? "unknown material"}). Inspect this image.` },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${base64}` } },
          ],
        },
      ],
      tools: [
        {
          type: "function",
          function: {
            name: "report_inspection",
            parameters: {
              type: "object",
              properties: {
                defects: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      defect_type: { type: "string", enum: [...DEFECT_TYPES] },
                      confidence: { type: "number" },
                      box_2d: { type: "array", items: { type: "number" } },
                      explanation: { type: "string" },
                    },
                    required: ["defect_type", "confidence", "box_2d", "explanation"],
                  },
                },
                no_defect_confidence: { type: "number" },
                summary: { type: "string" },
              },
              required: ["defects", "no_defect_confidence", "summary"],
            },
          },
        },
      ],
      tool_choice: { type: "function", function: { name: "report_inspection" } },
    }),
  });
  if (res.status === 429) throw new Error("AI model is rate-limited. Try again shortly or use Demo mode.");
  if (res.status === 402) throw new Error("AI credits exhausted. Use Demo (fallback) mode.");
  if (!res.ok) {
    console.error("AI gateway error", res.status, await res.text());
    throw new Error("AI model request failed. Use Demo (fallback) mode.");
  }
  const json = await res.json();
  const args = json.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
  if (!args) throw new Error("AI model returned no structured result");
  const parsed = JSON.parse(args) as {
    defects: { defect_type: string; confidence: number; box_2d: number[]; explanation: string }[];
    no_defect_confidence: number;
    summary: string;
  };
  const defects: Defect[] = (parsed.defects ?? [])
    .filter((d) => Array.isArray(d.box_2d) && d.box_2d.length === 4)
    .map((d) => {
      const [ymin = 0, xmin = 0, ymax = 0, xmax = 0] = d.box_2d.map((v) => Math.max(0, Math.min(1000, v)) / 1000);
      const conf = Math.max(0, Math.min(1, d.confidence));
      const box = { x: xmin, y: ymin, w: Math.max(0.01, xmax - xmin), h: Math.max(0.01, ymax - ymin) };
      return {
        defect_type: d.defect_type,
        confidence: Math.round(conf * 100) / 100,
        severity: computeSeverity(d.defect_type, box.w * box.h, conf),
        ...box,
        explanation: String(d.explanation).slice(0, 600),
      };
    });
  return { defects, noDefectConf: parsed.no_defect_confidence ?? 0.8, summary: parsed.summary ?? "" };
}

export const runInspection = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => inputSchema.parse(d))
  .handler(async ({ data }) => {
    const t0 = Date.now();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let profile: Profile | null = null;
    if (data.profileId) {
      const { data: p } = await supabaseAdmin.from("component_profiles").select("*").eq("id", data.profileId).maybeSingle();
      profile = (p as Profile) ?? null;
    }

    let defects: Defect[];
    let summary = "";
    let noDefectConf = 0.7;
    let modelName: string;
    if (data.mode === "ai") {
      const r = await aiInspect(data.imageBase64, profile);
      defects = r.defects;
      summary = r.summary;
      noDefectConf = r.noDefectConf;
      modelName = `Vision model (${MODEL})`;
    } else {
      defects = data.demoDefects ?? [];
      modelName = "DEMO FALLBACK: classical CV (Sobel + block anomaly)";
    }
    const v = computeVerdict(defects, profile);
    if (!summary)
      summary = v.kept.length
        ? `${v.kept.length} indication(s) above confidence threshold: ${[...new Set(v.kept.map((d) => d.defect_type))].join(", ")}.`
        : "No indications above confidence threshold.";
    const overall = v.kept.length ? Math.max(...v.kept.map((d) => d.confidence)) : Math.max(0, Math.min(1, noDefectConf));

    const bytes = Buffer.from(data.imageBase64, "base64");
    const path = `${new Date().toISOString().slice(0, 10)}/${crypto.randomUUID()}.jpg`;
    const up = await supabaseAdmin.storage.from("inspection-images").upload(path, bytes, { contentType: "image/jpeg" });
    if (up.error) throw new Error("Image storage failed");
    const { data: signed } = await supabaseAdmin.storage.from("inspection-images").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);

    const { data: ins, error } = await supabaseAdmin
      .from("inspections")
      .insert({
        profile_id: profile?.id ?? null,
        profile_name: profile?.name ?? "Generic",
        image_url: signed?.signedUrl ?? "",
        file_name: data.fileName,
        width: data.width,
        height: data.height,
        verdict: v.verdict,
        mode: data.mode,
        model_name: modelName,
        overall_confidence: overall,
        max_severity: v.maxSeverity,
        summary: [summary, ...v.reasons.map((r) => `• ${r}`)].join("\n"),
        recommended_action: v.recommendedAction,
        processing_ms: Date.now() - t0,
      })
      .select()
      .single();
    if (error || !ins) throw new Error("Failed to save inspection");
    if (v.kept.length) {
      await supabaseAdmin.from("defects").insert(v.kept.map((d) => ({ ...d, inspection_id: ins.id })));
    }
    return { id: ins.id };
  });

const profileSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().trim().min(2).max(60),
  description: z.string().max(300),
  material: z.string().max(80),
  min_confidence: z.number().min(0.05).max(0.99),
  fail_severity: z.enum(SEVERITIES),
  max_defects: z.number().int().min(0).max(50),
});

export const saveProfile = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => profileSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { id, ...rest } = data;
    const q = id
      ? supabaseAdmin.from("component_profiles").update(rest).eq("id", id)
      : supabaseAdmin.from("component_profiles").insert(rest);
    const { error } = await q;
    if (error) throw new Error(error.message.includes("duplicate") ? "A profile with that name exists" : "Save failed");
    return { ok: true };
  });

export const deleteProfile = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("component_profiles").delete().eq("id", data.id);
    if (error) throw new Error("Delete failed");
    return { ok: true };
  });
