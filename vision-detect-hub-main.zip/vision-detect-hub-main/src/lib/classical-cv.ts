// @ts-nocheck -- numeric typed-array indexing; bounds are guaranteed by loop limits
// DEMO / FALLBACK MODE — classical computer vision running in the browser.
// Pipeline (mirrors backend/app/preprocessing.py): grayscale -> Gaussian blur ->
// Sobel gradient magnitude + local darkness + rust-hue mask -> block anomaly
// z-scores -> connected components -> bounding boxes -> rule-based classification.
// This is deterministic image analysis, NOT a trained deep-learning model.
import { computeSeverity, type Defect } from "./severity";

export async function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => res(img);
    img.onerror = rej;
    img.src = src;
  });
}

export function classicalInspect(img: HTMLImageElement): Defect[] {
  const W = 256;
  const H = Math.round((img.naturalHeight / img.naturalWidth) * W);
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const ctx = c.getContext("2d")!;
  ctx.drawImage(img, 0, 0, W, H);
  const { data } = ctx.getImageData(0, 0, W, H);
  const gray = new Float32Array(W * H);
  const rust = new Float32Array(W * H);
  for (let i = 0; i < W * H; i++) {
    const r = data[i * 4], g = data[i * 4 + 1], b = data[i * 4 + 2];
    gray[i] = 0.299 * r + 0.587 * g + 0.114 * b;
    rust[i] = r > 90 && r > g * 1.25 && g > b * 1.1 ? 1 : 0;
  }
  // 3x3 box blur (approx Gaussian)
  const blur = new Float32Array(W * H);
  for (let y = 1; y < H - 1; y++)
    for (let x = 1; x < W - 1; x++) {
      let s = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) s += gray[(y + dy) * W + x + dx];
      blur[y * W + x] = s / 9;
    }
  // Sobel
  const mag = new Float32Array(W * H);
  for (let y = 1; y < H - 1; y++)
    for (let x = 1; x < W - 1; x++) {
      const p = (dx: number, dy: number) => blur[(y + dy) * W + x + dx];
      const gx = -p(-1, -1) - 2 * p(-1, 0) - p(-1, 1) + p(1, -1) + 2 * p(1, 0) + p(1, 1);
      const gy = -p(-1, -1) - 2 * p(0, -1) - p(1, -1) + p(-1, 1) + 2 * p(0, 1) + p(1, 1);
      mag[y * W + x] = Math.hypot(gx, gy);
    }
  // Block statistics
  const B = 8;
  const bw = Math.floor(W / B), bh = Math.floor(H / B);
  const edge = new Float32Array(bw * bh), dark = new Float32Array(bw * bh), rst = new Float32Array(bw * bh);
  let meanGray = 0;
  for (let i = 0; i < W * H; i++) meanGray += blur[i];
  meanGray /= W * H;
  for (let by = 0; by < bh; by++)
    for (let bx = 0; bx < bw; bx++) {
      let e = 0, d = 0, r = 0;
      for (let y = by * B; y < by * B + B; y++)
        for (let x = bx * B; x < bx * B + B; x++) {
          const i = y * W + x;
          e += mag[i];
          d += Math.max(0, meanGray - blur[i]);
          r += rust[i];
        }
      const n = B * B;
      edge[by * bw + bx] = e / n;
      dark[by * bw + bx] = d / n;
      rst[by * bw + bx] = r / n;
    }
  const z = (arr: Float32Array) => {
    let m = 0;
    for (const v of arr) m += v;
    m /= arr.length;
    let s = 0;
    for (const v of arr) s += (v - m) ** 2;
    s = Math.sqrt(s / arr.length) || 1;
    return Array.from(arr, (v) => (v - m) / s);
  };
  const ze = z(edge), zd = z(dark);
  const score = ze.map((v, i) => Math.max(v, zd[i] * 0.8, rst[i] > 0.35 ? 3 : 0));
  const mask = score.map((v) => v > 2.2);
  // connected components
  const seen = new Uint8Array(bw * bh);
  const out: Defect[] = [];
  for (let i = 0; i < bw * bh; i++) {
    if (!mask[i] || seen[i]) continue;
    const stack = [i];
    seen[i] = 1;
    let minx = bw, miny = bh, maxx = 0, maxy = 0, cnt = 0, sScore = 0, sRust = 0, sDark = 0;
    while (stack.length) {
      const k = stack.pop()!;
      const kx = k % bw, ky = Math.floor(k / bw);
      minx = Math.min(minx, kx); maxx = Math.max(maxx, kx);
      miny = Math.min(miny, ky); maxy = Math.max(maxy, ky);
      cnt++; sScore += score[k]; sRust += rst[k]; sDark += zd[k];
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = kx + dx, ny = ky + dy;
        if (nx < 0 || ny < 0 || nx >= bw || ny >= bh) continue;
        const nk = ny * bw + nx;
        if (mask[nk] && !seen[nk]) { seen[nk] = 1; stack.push(nk); }
      }
    }
    if (cnt < 2) continue;
    const gw = maxx - minx + 1, gh = maxy - miny + 1;
    const aspect = Math.max(gw, gh) / Math.min(gw, gh);
    const fill = cnt / (gw * gh);
    const avgScore = sScore / cnt;
    let type: string;
    if (sRust / cnt > 0.25) type = "Corrosion / Oxidation";
    else if (aspect >= 3 && fill < 0.6) type = sDark / cnt > 1 ? "Crack" : "Scratch";
    else if (sDark / cnt > 1.2 && cnt <= 12) type = "Surface Porosity";
    else if (cnt > 30) type = "Deformation / Structural";
    else type = "Surface Porosity";
    const confidence = Math.min(0.95, 0.35 + (avgScore - 2.2) * 0.18 + Math.min(cnt, 20) * 0.01);
    const box = { x: (minx * B) / W, y: (miny * B) / H, w: (gw * B) / W, h: (gh * B) / H };
    out.push({
      defect_type: type,
      confidence: Math.round(confidence * 100) / 100,
      severity: computeSeverity(type, box.w * box.h, confidence),
      ...box,
      explanation: `Classical CV: region of ${cnt} anomalous blocks (anomaly z≈${avgScore.toFixed(1)}, aspect ${aspect.toFixed(1)}, fill ${(fill * 100).toFixed(0)}%) classified by rule as ${type}.`,
    });
  }
  return out.sort((a, b) => b.confidence - a.confidence).slice(0, 8);
}

/** Downscale + JPEG-encode for upload; returns base64 (no prefix) and dims. */
export async function prepareImage(file: Blob, maxSide = 1600) {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement("canvas");
    c.width = Math.round(img.naturalWidth * scale);
    c.height = Math.round(img.naturalHeight * scale);
    c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
    const dataUrl = c.toDataURL("image/jpeg", 0.9);
    return { img, base64: dataUrl.split(",")[1], width: img.naturalWidth, height: img.naturalHeight, dataUrl };
  } finally {
    URL.revokeObjectURL(url);
  }
}
