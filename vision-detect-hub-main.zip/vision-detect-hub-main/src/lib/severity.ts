export const DEFECT_TYPES = [
  "Crack",
  "Surface Porosity",
  "Corrosion / Oxidation",
  "Scratch",
  "Deformation / Structural",
] as const;
export type DefectType = (typeof DEFECT_TYPES)[number];

export const SEVERITIES = ["Low", "Medium", "High", "Critical"] as const;
export type Severity = (typeof SEVERITIES)[number];

export const severityRank = (s: string) => {
  const i = SEVERITIES.indexOf(s as Severity);
  return i === -1 ? -1 : i;
};

export type Defect = {
  defect_type: string;
  confidence: number; // 0..1
  severity: Severity;
  x: number; // normalized 0..1
  y: number;
  w: number;
  h: number;
  explanation: string;
};

export type Profile = {
  id: string;
  name: string;
  description: string;
  material: string;
  min_confidence: number;
  fail_severity: string;
  max_defects: number;
};

/** Severity engine: combines defect type criticality, area and confidence. */
export function computeSeverity(type: string, areaFrac: number, confidence: number): Severity {
  const typeWeight: Record<string, number> = {
    Crack: 3,
    "Deformation / Structural": 2.5,
    "Surface Porosity": 1.5,
    "Corrosion / Oxidation": 1.5,
    Scratch: 1,
  };
  const score = (typeWeight[type] ?? 1) * (0.6 + confidence) * (1 + Math.min(areaFrac, 0.3) * 8);
  if (score >= 6) return "Critical";
  if (score >= 3.8) return "High";
  if (score >= 2.2) return "Medium";
  return "Low";
}

export type Verdict = {
  verdict: "PASS" | "FAIL";
  kept: Defect[];
  maxSeverity: string;
  reasons: string[];
  recommendedAction: string;
};

export function computeVerdict(defects: Defect[], profile: Profile | null): Verdict {
  const minConf = profile ? Number(profile.min_confidence) : 0.5;
  const failSev = profile?.fail_severity ?? "Medium";
  const maxDefects = profile?.max_defects ?? 0;
  const kept = defects.filter((d) => d.confidence >= minConf);
  const maxSeverity = kept.reduce<string>(
    (m, d) => (severityRank(d.severity) > severityRank(m) ? d.severity : m),
    "None",
  );
  const reasons: string[] = [];
  if (kept.some((d) => severityRank(d.severity) >= severityRank(failSev)))
    reasons.push(`Defect severity ≥ ${failSev} threshold for this profile`);
  if (kept.length > maxDefects)
    reasons.push(`${kept.length} defect(s) exceed allowed count of ${maxDefects}`);
  if (kept.some((d) => d.defect_type === "Crack"))
    reasons.push("Crack detected — cracks are never acceptable");
  const verdict = reasons.length ? "FAIL" : "PASS";
  const recommendedAction =
    verdict === "PASS"
      ? kept.length
        ? "Accept with note. Minor indications below rejection threshold; log for trend monitoring."
        : "Accept. No indications above threshold. Release to next process stage."
      : maxSeverity === "Critical"
        ? "Reject and quarantine immediately. Escalate to QA engineer; perform NDT (dye penetrant / ultrasonic) and root-cause analysis."
        : maxSeverity === "High"
          ? "Reject. Hold part for manual inspection and confirm with NDT before scrap or rework decision."
          : "Hold for manual re-inspection. Rework may be possible (grinding, re-coating, re-welding) per process spec.";
  return { verdict, kept, maxSeverity, reasons, recommendedAction };
}
