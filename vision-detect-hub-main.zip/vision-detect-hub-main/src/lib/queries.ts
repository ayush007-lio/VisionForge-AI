import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Profile } from "./severity";

export type DefectRow = {
  id: string;
  defect_type: string;
  confidence: number;
  severity: string;
  x: number;
  y: number;
  w: number;
  h: number;
  explanation: string;
};
export type InspectionRow = {
  id: string;
  profile_name: string;
  image_url: string;
  file_name: string;
  width: number | null;
  height: number | null;
  verdict: string;
  mode: string;
  model_name: string;
  overall_confidence: number;
  max_severity: string;
  summary: string;
  recommended_action: string;
  processing_ms: number;
  created_at: string;
  defects: DefectRow[];
};

export const profilesQuery = queryOptions({
  queryKey: ["profiles"],
  queryFn: async () => {
    const { data, error } = await supabase.from("component_profiles").select("*").order("name");
    if (error) throw error;
    return data as unknown as Profile[];
  },
});

export const inspectionsQuery = queryOptions({
  queryKey: ["inspections"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("inspections")
      .select("*, defects(*)")
      .order("created_at", { ascending: false })
      .limit(500);
    if (error) throw error;
    return data as unknown as InspectionRow[];
  },
});
