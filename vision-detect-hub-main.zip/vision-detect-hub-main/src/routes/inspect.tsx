import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { Loader2, Upload, Cpu, FlaskConical } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InspectionReport } from "@/components/InspectionReport";
import { inspectionsQuery, profilesQuery, type InspectionRow } from "@/lib/queries";
import { runInspection } from "@/lib/inspection.functions";
import { classicalInspect, prepareImage } from "@/lib/classical-cv";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/inspect")({
  head: () => ({
    meta: [
      { title: "Run Inspection — AI Industrial Defect Detection" },
      { name: "description", content: "Upload a component image for AI defect detection, classification and PASS/FAIL verdict." },
      { property: "og:title", content: "Run Inspection — AI Industrial Defect Detection" },
      { property: "og:description", content: "Upload an industrial component image and inspect it with computer vision." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(profilesQuery),
  component: InspectPage,
});

const SAMPLES = [
  { file: "/samples/weld.jpg", label: "Welded joint", profile: "Welded Joint" },
  { file: "/samples/casting.jpg", label: "Cast engine block", profile: "Cast Engine Block" },
  { file: "/samples/sheet.jpg", label: "Structural sheet", profile: "Sheet Metal" },
  { file: "/samples/machined.jpg", label: "Machined flange", profile: "Machined Part" },
];
const ACCEPT = ["image/jpeg", "image/png", "image/webp", "image/bmp"];
const MAX_MB = 10;
const STAGES = ["Validating image", "Preprocessing (resize, normalize)", "Running model inference", "Severity engine & verdict", "Saving result"];

function InspectPage() {
  const { data: profiles } = useSuspenseQuery(profilesQuery);
  const qc = useQueryClient();
  const run = useServerFn(runInspection);
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<{ blob: Blob; name: string; preview: string } | null>(null);
  const [profileId, setProfileId] = useState<string>(profiles[0]?.id ?? "");
  const [mode, setMode] = useState<"ai" | "demo">("ai");
  const [stage, setStage] = useState(-1);
  const [result, setResult] = useState<InspectionRow | null>(null);

  const pick = async (blob: Blob, name: string): Promise<void> => {
    if (!ACCEPT.includes(blob.type)) { toast.error("Unsupported format. Use JPG, PNG, WEBP or BMP."); return; }
    if (blob.size > MAX_MB * 1024 * 1024) { toast.error(`File exceeds ${MAX_MB} MB.`); return; }
    setResult(null);
    setFile({ blob, name, preview: URL.createObjectURL(blob) });
  };

  const loadSample = async (s: (typeof SAMPLES)[number]) => {
    const blob = await (await fetch(s.file)).blob();
    const p = profiles.find((p) => p.name === s.profile);
    if (p) setProfileId(p.id);
    pick(blob, s.file.split("/").pop()!);
  };

  const inspect = async () => {
    if (!file) return;
    try {
      setStage(0);
      const prep = await prepareImage(file.blob);
      if (prep.width < 128 || prep.height < 128) throw new Error("Resolution too low (min 128×128).");
      setStage(1);
      await new Promise((r) => setTimeout(r, 150));
      setStage(2);
      const demoDefects = mode === "demo" ? classicalInspect(prep.img) : undefined;
      const { id } = await run({
        data: { imageBase64: prep.base64, fileName: file.name, width: prep.width, height: prep.height, profileId: profileId || null, mode, demoDefects },
      });
      setStage(4);
      const list = await qc.fetchQuery({ ...inspectionsQuery, staleTime: 0 });
      setResult(list.find((i) => i.id === id) ?? null);
      qc.invalidateQueries({ queryKey: ["inspections"] });
      toast.success("Inspection complete");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Inspection failed");
    } finally {
      setStage(-1);
    }
  };

  const busy = stage >= 0;
  return (
    <div className="space-y-6">
      <div>
        <p className="font-mono text-xs uppercase tracking-widest text-primary">Station 01</p>
        <h1 className="text-3xl font-bold">Run inspection</h1>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <Card
          className={cn("grid-bg flex min-h-72 cursor-pointer items-center justify-center overflow-hidden border-dashed p-4", busy && "pointer-events-none")}
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            const f = e.dataTransfer.files[0];
            if (f) pick(f, f.name);
          }}
        >
          <input ref={inputRef} type="file" accept={ACCEPT.join(",")} hidden onChange={(e) => e.target.files?.[0] && pick(e.target.files[0], e.target.files[0].name)} />
          {file ? (
            <img src={file.preview} alt="Selected component" className="max-h-96 rounded" />
          ) : (
            <div className="text-center text-muted-foreground">
              <Upload className="mx-auto mb-2 h-8 w-8" />
              <p>Drop a component image or click to browse</p>
              <p className="font-mono text-xs">JPG · PNG · WEBP · BMP — max {MAX_MB} MB, min 128×128 px</p>
            </div>
          )}
        </Card>

        <Card className="space-y-4 p-4">
          <div>
            <label className="font-mono text-xs uppercase text-muted-foreground">Inspection profile</label>
            <Select value={profileId} onValueChange={setProfileId}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select profile" /></SelectTrigger>
              <SelectContent>
                {profiles.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="font-mono text-xs uppercase text-muted-foreground">Engine</label>
            <div className="mt-1 grid grid-cols-2 gap-2">
              <button onClick={() => setMode("ai")} className={cn("rounded border p-2 text-left text-xs", mode === "ai" && "border-primary bg-primary/10")}>
                <Cpu className="mb-1 h-4 w-4" /><b>AI vision model</b><br /><span className="text-muted-foreground">Cloud multimodal detector</span>
              </button>
              <button onClick={() => setMode("demo")} className={cn("rounded border p-2 text-left text-xs", mode === "demo" && "border-primary bg-primary/10")}>
                <FlaskConical className="mb-1 h-4 w-4" /><b>Demo / fallback</b><br /><span className="text-muted-foreground">Offline classical CV</span>
              </button>
            </div>
            {mode === "demo" && (
              <p className="mt-2 text-[11px] text-warning">Fallback runs in-browser edge/anomaly analysis — clearly labelled, not a trained deep model.</p>
            )}
          </div>
          <Button className="w-full" disabled={!file || busy} onClick={inspect}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Inspect component
          </Button>
          {busy && (
            <ol className="space-y-1 font-mono text-xs">
              {STAGES.map((s, i) => (
                <li key={s} className={i < stage ? "text-success" : i === stage ? "text-primary" : "text-muted-foreground"}>
                  {i < stage ? "✓" : i === stage ? "›" : "·"} {s}
                </li>
              ))}
            </ol>
          )}
        </Card>
      </div>

      <div>
        <h3 className="mb-2 font-mono text-xs uppercase text-muted-foreground">Preloaded test components</h3>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {SAMPLES.map((s) => (
            <button key={s.file} disabled={busy} onClick={() => loadSample(s)} className="group overflow-hidden rounded border text-left hover:border-primary">
              <img src={s.file} alt={s.label} loading="lazy" width={1024} height={768} className="aspect-[4/3] w-full object-cover transition group-hover:scale-105" />
              <div className="p-2 text-xs">{s.label}</div>
            </button>
          ))}
        </div>
      </div>

      {result && (
        <Card className="p-4">
          <h2 className="mb-4 font-mono text-xs uppercase text-muted-foreground">Inspection result</h2>
          <InspectionReport ins={result} />
        </Card>
      )}
    </div>
  );
}
