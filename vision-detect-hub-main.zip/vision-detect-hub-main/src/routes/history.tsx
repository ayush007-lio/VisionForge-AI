import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InspectionReport, downloadFile } from "@/components/InspectionReport";
import { inspectionsQuery, type InspectionRow } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Inspection History — AI Industrial Defect Detection" },
      { name: "description", content: "Searchable, filterable log of all component inspections with exportable reports." },
      { property: "og:title", content: "Inspection History — AI Industrial Defect Detection" },
      { property: "og:description", content: "Browse and export past AI inspection results." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(inspectionsQuery),
  component: HistoryPage,
});

function HistoryPage() {
  const { data } = useSuspenseQuery(inspectionsQuery);
  const [q, setQ] = useState("");
  const [verdict, setVerdict] = useState("all");
  const [mode, setMode] = useState("all");
  const [open, setOpen] = useState<InspectionRow | null>(null);

  const rows = useMemo(
    () =>
      data.filter(
        (r) =>
          (verdict === "all" || r.verdict === verdict) &&
          (mode === "all" || r.mode === mode) &&
          `${r.profile_name} ${r.file_name} ${r.defects.map((d) => d.defect_type).join(" ")} ${r.id}`.toLowerCase().includes(q.toLowerCase()),
      ),
    [data, q, verdict, mode],
  );

  const exportCsv = () => {
    const head = ["id", "timestamp", "profile", "file", "verdict", "mode", "confidence", "max_severity", "defect_count", "defect_types"];
    const lines = rows.map((r) =>
      [r.id, r.created_at, r.profile_name, r.file_name, r.verdict, r.mode, r.overall_confidence, r.max_severity, r.defects.length, r.defects.map((d) => d.defect_type).join("|")]
        .map((v) => `"${String(v).replace(/"/g, '""')}"`)
        .join(","),
    );
    downloadFile("inspection-history.csv", [head.join(","), ...lines].join("\n"), "text/csv");
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="text-3xl font-bold">Inspection history</h1>
        <Button variant="outline" onClick={exportCsv} disabled={!rows.length}><Download className="h-4 w-4" /> Export CSV</Button>
      </div>
      <div className="flex flex-wrap gap-2">
        <Input placeholder="Search profile, file, defect type…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
        <Select value={verdict} onValueChange={setVerdict}>
          <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All verdicts</SelectItem><SelectItem value="PASS">PASS</SelectItem><SelectItem value="FAIL">FAIL</SelectItem></SelectContent>
        </Select>
        <Select value={mode} onValueChange={setMode}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All engines</SelectItem><SelectItem value="ai">AI model</SelectItem><SelectItem value="demo">Demo fallback</SelectItem></SelectContent>
        </Select>
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b font-mono text-[11px] uppercase text-muted-foreground">
            <tr>{["", "Time", "Profile", "Verdict", "Defects", "Severity", "Conf.", "Engine"].map((h) => <th key={h} className="p-3 text-left">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="cursor-pointer border-b hover:bg-accent/50" onClick={() => setOpen(r)}>
                <td className="p-2"><img src={r.image_url} alt="" className="h-10 w-14 rounded object-cover" /></td>
                <td className="p-3 font-mono text-xs">{new Date(r.created_at).toLocaleString()}</td>
                <td className="p-3">{r.profile_name}</td>
                <td className={cn("p-3 font-mono font-bold", r.verdict === "PASS" ? "text-success" : "text-destructive")}>{r.verdict}</td>
                <td className="p-3 text-xs">{r.defects.length ? [...new Set(r.defects.map((d) => d.defect_type))].join(", ") : "—"}</td>
                <td className="p-3">{r.max_severity}</td>
                <td className="p-3 font-mono">{Math.round(r.overall_confidence * 100)}%</td>
                <td className="p-3 text-xs">{r.mode === "demo" ? "Demo" : "AI"}</td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">No inspections match.</td></tr>}
          </tbody>
        </table>
      </Card>
      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent className="max-h-[90vh] max-w-5xl overflow-y-auto">
          <DialogHeader><DialogTitle>Inspection report</DialogTitle></DialogHeader>
          {open && <InspectionReport ins={open} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}
