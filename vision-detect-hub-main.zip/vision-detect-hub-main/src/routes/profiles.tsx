import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { profilesQuery } from "@/lib/queries";
import { deleteProfile, saveProfile } from "@/lib/inspection.functions";
import { SEVERITIES, type Profile } from "@/lib/severity";

export const Route = createFileRoute("/profiles")({
  head: () => ({
    meta: [
      { title: "Inspection Profiles — AI Industrial Defect Detection" },
      { name: "description", content: "Manage component inspection profiles and their defect acceptance thresholds." },
      { property: "og:title", content: "Inspection Profiles — AI Industrial Defect Detection" },
      { property: "og:description", content: "Customize defect thresholds per component type." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(profilesQuery),
  component: ProfilesPage,
});

type Draft = Omit<Profile, "id"> & { id?: string };
const empty: Draft = { name: "", description: "", material: "", min_confidence: 0.5, fail_severity: "Medium", max_defects: 0 };

function ProfilesPage() {
  const { data } = useSuspenseQuery(profilesQuery);
  const qc = useQueryClient();
  const save = useServerFn(saveProfile);
  const del = useServerFn(deleteProfile);
  const [draft, setDraft] = useState<Draft | null>(null);

  const submit = async () => {
    if (!draft) return;
    try {
      await save({ data: { ...draft, min_confidence: Number(draft.min_confidence), max_defects: Number(draft.max_defects), fail_severity: draft.fail_severity as (typeof SEVERITIES)[number] } });
      toast.success("Profile saved");
      setDraft(null);
      qc.invalidateQueries({ queryKey: ["profiles"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold">Inspection profiles</h1>
          <p className="text-sm text-muted-foreground">Thresholds used by the verdict engine for each component type.</p>
        </div>
        <Button onClick={() => setDraft({ ...empty })}><Plus className="h-4 w-4" /> New profile</Button>
      </div>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {data.map((p) => (
          <Card key={p.id} className="p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold">{p.name}</h3>
                <p className="text-xs text-muted-foreground">{p.material}</p>
              </div>
              <div className="flex gap-1">
                <Button size="icon" variant="ghost" onClick={() => setDraft({ ...p })} aria-label="Edit"><Pencil className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" aria-label="Delete" onClick={async () => {
                  if (!confirm(`Delete ${p.name}?`)) return;
                  await del({ data: { id: p.id } });
                  qc.invalidateQueries({ queryKey: ["profiles"] });
                }}><Trash2 className="h-4 w-4" /></Button>
              </div>
            </div>
            <p className="mt-2 text-sm">{p.description}</p>
            <dl className="mt-3 grid grid-cols-3 gap-2 font-mono text-xs">
              <div><dt className="text-muted-foreground">Min conf</dt><dd>{Math.round(p.min_confidence * 100)}%</dd></div>
              <div><dt className="text-muted-foreground">Fail at</dt><dd>≥ {p.fail_severity}</dd></div>
              <div><dt className="text-muted-foreground">Max defects</dt><dd>{p.max_defects}</dd></div>
            </dl>
          </Card>
        ))}
      </div>
      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{draft?.id ? "Edit profile" : "New profile"}</DialogTitle></DialogHeader>
          {draft && (
            <div className="space-y-3 text-sm">
              <Input placeholder="Name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
              <Input placeholder="Material" value={draft.material} onChange={(e) => setDraft({ ...draft, material: e.target.value })} />
              <Input placeholder="Description" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
              <div className="grid grid-cols-3 gap-2">
                <label>Min confidence<Input type="number" step="0.05" min="0.05" max="0.99" value={draft.min_confidence} onChange={(e) => setDraft({ ...draft, min_confidence: +e.target.value })} /></label>
                <label>Fail at severity
                  <Select value={draft.fail_severity} onValueChange={(v) => setDraft({ ...draft, fail_severity: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{SEVERITIES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select>
                </label>
                <label>Max defects<Input type="number" min="0" value={draft.max_defects} onChange={(e) => setDraft({ ...draft, max_defects: +e.target.value })} /></label>
              </div>
              <Button className="w-full" onClick={submit}>Save</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
