import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/architecture")({
  head: () => ({
    meta: [
      { title: "System Architecture — AI Industrial Defect Detection" },
      { name: "description", content: "How the inspection pipeline, models, fallback mode and Python backend fit together." },
      { property: "og:title", content: "System Architecture — AI Industrial Defect Detection" },
      { property: "og:description", content: "Pipeline, models and companion FastAPI/YOLO backend explained." },
    ],
  }),
  component: Arch,
});

const steps = [
  ["1. Validate", "Format (JPG/PNG/WEBP/BMP), size ≤ 10 MB, resolution ≥ 128 px."],
  ["2. Preprocess", "Resize to ≤ 1600 px, JPEG normalize. Backend: denoise, CLAHE, normalize (OpenCV)."],
  ["3. Inference", "AI mode: multimodal vision model returns classes + boxes. Local backend: YOLOv8 detector."],
  ["4. Severity engine", "Score = type weight × confidence × defect area → Low / Medium / High / Critical."],
  ["5. Verdict", "Profile thresholds: min confidence, fail-at severity, max defect count, cracks always fail."],
  ["6. Persist", "Image to private storage; inspection + defect boxes to the database; analytics update."],
];

function Arch() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">System architecture</h1>
      <div className="grid gap-3 md:grid-cols-3">
        {steps.map(([t, d]) => (
          <Card key={t} className="p-4"><h3 className="font-mono text-sm text-primary">{t}</h3><p className="mt-1 text-sm text-muted-foreground">{d}</p></Card>
        ))}
      </div>
      <Card className="space-y-3 p-5 text-sm">
        <h2 className="font-semibold">Engines</h2>
        <p><b>AI vision model</b> — the web app sends the preprocessed image to a hosted multimodal vision model with a strict structured-output schema (class, confidence, box). No random values are generated.</p>
        <p><b>Demo / fallback mode</b> — runs entirely in the browser: grayscale → blur → Sobel gradients → block anomaly z-scores → connected components → rule-based classification. It is deterministic classical CV and is always labelled as DEMO in results.</p>
        <p><b>Companion backend (<code>backend/</code>)</b> — a standalone Python FastAPI service with an OpenCV preprocessing pipeline, Ultralytics YOLOv8 training/inference, dataset layout (NEU-DET / MVTec style) and evaluation scripts (mAP, precision/recall, confusion matrix). Run it locally with <code>uvicorn app.main:app</code> to demo a self-trained model.</p>
        <p className="text-warning">This is an academic demonstration project. It is not connected to BEML or any real production line and its results are not certified inspections.</p>
      </Card>
    </div>
  );
}
