import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ScanSearch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { inspectionsQuery } from "@/lib/queries";
import { DEFECT_TYPES, SEVERITIES } from "@/lib/severity";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — AI Industrial Defect Detection" },
      { name: "description", content: "Pass/fail ratios, defect distribution, severity and inspection volume analytics." },
      { property: "og:title", content: "Dashboard — AI Industrial Defect Detection" },
      { property: "og:description", content: "Live analytics for an academic AI visual inspection system." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(inspectionsQuery),
  component: Dashboard,
});

const tip = { contentStyle: { background: "var(--card)", border: "1px solid var(--border)", fontSize: 12 } };
const C = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <Card className="p-4">
      <div className="font-mono text-[11px] uppercase text-muted-foreground">{label}</div>
      <div className="mt-1 font-mono text-3xl font-bold">{value}</div>
      {sub && <div className="text-xs text-muted-foreground">{sub}</div>}
    </Card>
  );
}

function Dashboard() {
  const { data } = useSuspenseQuery(inspectionsQuery);
  const total = data.length;
  const fails = data.filter((d) => d.verdict === "FAIL").length;
  const defects = data.flatMap((d) => d.defects);
  const avgConf = total ? data.reduce((s, d) => s + Number(d.overall_confidence), 0) / total : 0;

  const byType = DEFECT_TYPES.map((t) => ({ name: t.split(" ")[0], value: defects.filter((d) => d.defect_type === t).length }));
  const bySev = SEVERITIES.map((s) => ({ name: s, value: defects.filter((d) => d.severity === s).length }));
  const days = new Map<string, { day: string; PASS: number; FAIL: number; conf: number; n: number }>();
  [...data].reverse().forEach((d) => {
    const day = d.created_at.slice(0, 10);
    const e = days.get(day) ?? { day, PASS: 0, FAIL: 0, conf: 0, n: 0 };
    e[d.verdict as "PASS" | "FAIL"]++;
    e.conf += Number(d.overall_confidence);
    e.n++;
    days.set(day, e);
  });
  const timeline = [...days.values()].map((e) => ({ ...e, conf: Math.round((e.conf / e.n) * 100) }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-primary">Inspection control room</p>
          <h1 className="text-3xl font-bold">AI-Based Industrial Defect Detection</h1>
          <p className="max-w-2xl text-sm text-muted-foreground">
            Upload a component image, run the vision model, and get a PASS/FAIL verdict with localized, classified defects.
          </p>
        </div>
        <Button asChild>
          <Link to="/inspect"><ScanSearch className="h-4 w-4" /> New inspection</Link>
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Inspections" value={String(total)} />
        <Stat label="Pass rate" value={total ? `${Math.round(((total - fails) / total) * 100)}%` : "—"} sub={`${total - fails} pass / ${fails} fail`} />
        <Stat label="Defects found" value={String(defects.length)} />
        <Stat label="Avg confidence" value={total ? `${Math.round(avgConf * 100)}%` : "—"} />
      </div>

      {total === 0 ? (
        <Card className="grid-bg p-12 text-center">
          <p className="text-muted-foreground">No inspections yet. Run one with a demo sample to populate analytics.</p>
          <Button asChild className="mt-4"><Link to="/inspect">Start inspecting</Link></Button>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="p-4">
            <h3 className="mb-2 font-mono text-xs uppercase text-muted-foreground">Pass vs fail</h3>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={[{ name: "PASS", value: total - fails }, { name: "FAIL", value: fails }]} dataKey="value" innerRadius={55} outerRadius={90} label>
                  <Cell fill="var(--success)" />
                  <Cell fill="var(--destructive)" />
                </Pie>
                <Tooltip {...tip} />
              </PieChart>
            </ResponsiveContainer>
          </Card>
          <Card className="p-4">
            <h3 className="mb-2 font-mono text-xs uppercase text-muted-foreground">Defect distribution by type</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={byType}>
                <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis allowDecimals={false} stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip {...tip} />
                <Bar dataKey="value">{byType.map((_, i) => <Cell key={i} fill={C[i]} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card className="p-4">
            <h3 className="mb-2 font-mono text-xs uppercase text-muted-foreground">Severity breakdown</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={bySev} layout="vertical">
                <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                <XAxis type="number" allowDecimals={false} stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis type="category" dataKey="name" stroke="var(--muted-foreground)" fontSize={11} width={70} />
                <Tooltip {...tip} />
                <Bar dataKey="value">
                  {bySev.map((_, i) => <Cell key={i} fill={["var(--chart-4)", "var(--warning)", "var(--chart-1)", "var(--destructive)"][i]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card className="p-4">
            <h3 className="mb-2 font-mono text-xs uppercase text-muted-foreground">Inspection volume & avg confidence over time</h3>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={timeline}>
                <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis yAxisId="l" allowDecimals={false} stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis yAxisId="r" orientation="right" domain={[0, 100]} stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip {...tip} />
                <Line yAxisId="l" dataKey="PASS" stroke="var(--success)" strokeWidth={2} />
                <Line yAxisId="l" dataKey="FAIL" stroke="var(--destructive)" strokeWidth={2} />
                <Line yAxisId="r" dataKey="conf" name="Avg conf %" stroke="var(--primary)" strokeDasharray="4 3" />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>
      )}
    </div>
  );
}
