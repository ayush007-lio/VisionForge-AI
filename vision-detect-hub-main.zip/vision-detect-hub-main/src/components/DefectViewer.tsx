import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

type Box = { defect_type: string; confidence: number; severity: string; x: number; y: number; w: number; h: number };

export const sevClass: Record<string, string> = {
  Low: "border-chart-4 text-chart-4",
  Medium: "border-warning text-warning",
  High: "border-chart-1 text-chart-1",
  Critical: "border-destructive text-destructive",
};

export function DefectViewer({ src, defects, className }: { src: string; defects: Box[]; className?: string }) {
  const [mode, setMode] = useState<"boxes" | "heatmap" | "none">("boxes");
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c || mode !== "heatmap") return;
    const W = 200, H = 150;
    c.width = W;
    c.height = H;
    const ctx = c.getContext("2d")!;
    const img = ctx.createImageData(W, H);
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        let v = 0;
        for (const d of defects) {
          const cx = (d.x + d.w / 2) * W, cy = (d.y + d.h / 2) * H;
          const sx = Math.max(3, (d.w * W) / 2), sy = Math.max(3, (d.h * H) / 2);
          v += d.confidence * Math.exp(-(((x - cx) / sx) ** 2 + ((y - cy) / sy) ** 2));
        }
        v = Math.min(1, v);
        const i = (y * W + x) * 4;
        img.data[i] = 255 * Math.min(1, v * 2);
        img.data[i + 1] = 255 * Math.max(0, Math.min(1, v * 2 - 0.4) ) * 0.8;
        img.data[i + 2] = 255 * Math.max(0, 0.6 - v);
        img.data[i + 3] = 40 + v * 150;
      }
    ctx.putImageData(img, 0, 0);
  }, [mode, defects]);

  return (
    <div className={cn("space-y-2", className)}>
      <div className="relative overflow-hidden rounded border bg-black/40">
        <img src={src} alt="Inspected component" className="block w-full" />
        {mode === "heatmap" && <canvas ref={canvasRef} className="absolute inset-0 h-full w-full mix-blend-screen" />}
        {mode === "boxes" &&
          defects.map((d, i) => (
            <div
              key={i}
              className={cn("absolute border-2", sevClass[d.severity] ?? "border-primary text-primary")}
              style={{ left: `${d.x * 100}%`, top: `${d.y * 100}%`, width: `${d.w * 100}%`, height: `${d.h * 100}%` }}
            >
              <span className="absolute -top-5 left-0 whitespace-nowrap bg-background/90 px-1 font-mono text-[10px]">
                #{i + 1} {d.defect_type} {(d.confidence * 100).toFixed(0)}%
              </span>
            </div>
          ))}
      </div>
      <div className="flex gap-1 font-mono text-xs">
        {(["boxes", "heatmap", "none"] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={cn("rounded border px-2 py-1 uppercase", mode === m ? "border-primary text-primary" : "text-muted-foreground")}
          >
            {m === "none" ? "original" : m}
          </button>
        ))}
      </div>
    </div>
  );
}
