import { CheckCircle2, XCircle, Download, Printer } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DefectViewer, sevClass } from "./DefectViewer";
import type { InspectionRow } from "@/lib/queries";
import { cn } from "@/lib/utils";

export function downloadFile(name: string, content: string, type: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([content], { type }));
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

export function InspectionReport({ ins }: { ins: InspectionRow }) {
  const pass = ins.verdict === "PASS";
  return (
    <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
      <DefectViewer src={ins.image_url} defects={ins.defects} />
      <div className="space-y-4">
        <div className={cn("flex items-center gap-3 rounded border-2 p-4", pass ? "border-success bg-success/10" : "border-destructive bg-destructive/10")}>
          {pass ? <CheckCircle2 className="h-10 w-10 text-success" /> : <XCircle className="h-10 w-10 text-destructive" />}
          <div>
            <div className={cn("font-mono text-3xl font-bold", pass ? "text-success" : "text-destructive")}>{ins.verdict}</div>
            <div className="text-xs text-muted-foreground">
              Confidence {(ins.overall_confidence * 100).toFixed(0)}% · Max severity {ins.max_severity}
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 text-xs">
          <Badge variant={ins.mode === "demo" ? "secondary" : "default"}>{ins.mode === "demo" ? "DEMO / FALLBACK MODE" : "AI MODEL"}</Badge>
          <Badge variant="outline">{ins.profile_name}</Badge>
          <Badge variant="outline" className="font-mono">{ins.processing_ms} ms</Badge>
        </div>
        <p className="text-xs text-muted-foreground">Model: {ins.model_name}</p>
        <div>
          <h4 className="mb-1 font-mono text-xs uppercase text-muted-foreground">Explanation</h4>
          <p className="whitespace-pre-line text-sm">{ins.summary}</p>
        </div>
        <div>
          <h4 className="mb-1 font-mono text-xs uppercase text-muted-foreground">Recommended action</h4>
          <p className="text-sm">{ins.recommended_action}</p>
        </div>
        {ins.defects.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-mono text-xs uppercase text-muted-foreground">Defects ({ins.defects.length})</h4>
            {ins.defects.map((d, i) => (
              <div key={d.id ?? i} className="rounded border p-2 text-sm">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium">#{i + 1} {d.defect_type}</span>
                  <span className={cn("rounded border px-1.5 font-mono text-[10px]", sevClass[d.severity])}>{d.severity}</span>
                </div>
                <div className="font-mono text-[11px] text-muted-foreground">
                  conf {(d.confidence * 100).toFixed(0)}% · bbox x{(+d.x).toFixed(2)} y{(+d.y).toFixed(2)} w{(+d.w).toFixed(2)} h{(+d.h).toFixed(2)}
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{d.explanation}</p>
              </div>
            ))}
          </div>
        )}
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => downloadFile(`inspection-${ins.id}.json`, JSON.stringify(ins, null, 2), "application/json")}>
            <Download className="h-4 w-4" /> JSON report
          </Button>
          <Button size="sm" variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4" /> Print
          </Button>
        </div>
        <p className="font-mono text-[10px] text-muted-foreground">
          ID {ins.id} · {new Date(ins.created_at).toLocaleString()} · Academic demonstration — not a certified inspection.
        </p>
      </div>
    </div>
  );
}
