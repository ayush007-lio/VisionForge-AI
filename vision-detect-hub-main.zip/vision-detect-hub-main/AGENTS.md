# Agent rules
- Inspection writes go through server functions using the admin client; tables are public-read only (no auth in this academic demo) — keeps the demo login-free while blocking direct client writes.
- Verdict/severity logic lives in src/lib/severity.ts and is mirrored in backend/app/severity.py — keep both in sync.
- Images are stored in a private bucket with long-lived signed URLs because public buckets are blocked in this workspace.
- Demo mode = in-browser classical CV (src/lib/classical-cv.ts); must always be labelled DEMO, never presented as a model prediction.
