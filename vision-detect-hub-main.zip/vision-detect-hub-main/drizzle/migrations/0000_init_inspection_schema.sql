
CREATE TABLE public.component_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text NOT NULL DEFAULT '',
  material text NOT NULL DEFAULT '',
  min_confidence numeric NOT NULL DEFAULT 0.5,
  fail_severity text NOT NULL DEFAULT 'Medium',
  max_defects integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.component_profiles TO anon, authenticated;
GRANT ALL ON public.component_profiles TO service_role;
ALTER TABLE public.component_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read profiles" ON public.component_profiles FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.inspections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES public.component_profiles(id) ON DELETE SET NULL,
  profile_name text NOT NULL DEFAULT '',
  image_url text NOT NULL,
  file_name text NOT NULL DEFAULT '',
  width integer,
  height integer,
  verdict text NOT NULL,
  mode text NOT NULL,
  model_name text NOT NULL,
  overall_confidence numeric NOT NULL DEFAULT 0,
  max_severity text NOT NULL DEFAULT 'None',
  summary text NOT NULL DEFAULT '',
  recommended_action text NOT NULL DEFAULT '',
  processing_ms integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.inspections TO anon, authenticated;
GRANT ALL ON public.inspections TO service_role;
ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read inspections" ON public.inspections FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.defects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_id uuid NOT NULL REFERENCES public.inspections(id) ON DELETE CASCADE,
  defect_type text NOT NULL,
  confidence numeric NOT NULL,
  severity text NOT NULL,
  x numeric NOT NULL, y numeric NOT NULL, w numeric NOT NULL, h numeric NOT NULL,
  explanation text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.defects TO anon, authenticated;
GRANT ALL ON public.defects TO service_role;
ALTER TABLE public.defects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read defects" ON public.defects FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX ON public.defects(inspection_id);
CREATE INDEX ON public.inspections(created_at DESC);

INSERT INTO public.component_profiles (name, description, material, min_confidence, fail_severity, max_defects) VALUES
('Turbine Blade','Aerospace-grade blade; zero tolerance for cracks.','Nickel superalloy',0.4,'Low',0),
('Welded Joint','Structural weld seams: porosity, cracks, undercut.','Carbon steel',0.5,'Medium',0),
('Cast Engine Block','Cast housings: porosity and shrinkage cavities.','Cast iron / aluminium',0.55,'Medium',1),
('Sheet Metal','Formed panels: scratches, dents, corrosion.','Galvanised steel',0.6,'High',2),
('Machined Part','Precision machined components: surface finish defects.','Tool steel',0.5,'Medium',0);
