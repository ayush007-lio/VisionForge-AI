# Defect Sense AI

Build a complete, functional, production-quality full-stack web application named "AI-Based Industrial Defect Detection System" based on the attached specification.

Implement the full end-to-end inspection platform:
1. Inspection Workflow:
   - Component image upload with validation (formats, resolution, size)
   - Real visual defect analysis and localization with bounding boxes/defect heatmaps
   - Defect classification (cracks, surface porosity, corrosion/oxidation, scratches, deformation/structural defects)
   - Confidence scoring and severity engine (Low, Medium, High, Critical)
   - Clear PASS / FAIL verdict calculation with engineering explanations and recommended inspection actions
2. Demo / Fallback Mode:
   - Preloaded realistic industrial test components (welds, castings, machined metal parts, structural surfaces) for reliable demonstration during interviews without relying on live external servers
   - Clearly labelled academic/demonstration system
3. Database & Storage:
   - Lovable Cloud database storing component types, inspection logs, defect coordinates, severities, and timestamps
   - Image storage for inspected parts
4. Dashboard & Analytics:
   - Recharts visual analytics: Pass vs. Fail ratios, defect distribution by type, severity breakdown, inspection volume over time, average confidence
   - Filterable, searchable inspection history log with details modal and report export
5. Component Management:
   - Manage inspection profiles (e.g. Turbine Blade, Welded Joint, Cast Engine Block, Sheet Metal) with customized defect thresholds
6. Companion Backend & Model Code:
   - Include a complete standalone `backend/` directory in the codebase containing the Python FastAPI server, OpenCV preprocessing pipeline, PyTorch/YOLO inference and training scripts, dataset directory structure, and evaluation utilities so it can be demonstrated or run locally for academic and interview presentation.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/bd6e6e11-1725-4e73-bebf-916ab3dc8c55).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
